<?php
    echo "<h1>Bem-vindo à nossa loja de roupas!</h1>";
    echo "<p>Veja nossas últimas novidades em roupas masculinas e femininas.</p>";
?>
