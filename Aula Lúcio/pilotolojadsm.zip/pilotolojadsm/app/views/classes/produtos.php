<?php
    echo "<h2>Nossos Produtos</h2>";
    echo "<div class='produto'>";
    echo "<h3>Camisa Polo</h3>";
    echo "<p>R$ 49,90</p>";
    echo "<button class='add-carrinho' data-produto='Camisa Polo'>Adicionar ao Carrinho</button>";
    echo "</div>";

    echo "<div class='produto'>";
    echo "<h3>Calça Jeans</h3>";
    echo "<p>R$ 79,90</p>";
    echo "<button class='add-carrinho' data-produto='Calça Jeans'>Adicionar ao Carrinho</button>";
    echo "</div>";
?>
